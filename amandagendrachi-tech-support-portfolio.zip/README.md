# 🧩 Amanda Gendrachi – Technical Support Portfolio

Welcome!  
This portfolio highlights a few of my practical projects demonstrating technical troubleshooting, scripting, and system management skills. Each example showcases my ability to work with Python, SQL, Linux command-line tools, and basic cybersecurity practices — the same core skills I bring to a Technical Support Analyst role.

---

## 🧹 1. CSV Data Cleaner (Python)

Python script that cleans and organizes CSV data by removing duplicates, filling gaps, and standardizing fields.

---

## 🧠 2. SQL Order Analytics (SQLite)

Example SQL file for creating a simple orders database and querying customer spending totals.

---

## 💻 3. Linux CLI Practice

Sample terminal session demonstrating directory navigation, file permissions, and Python environment setup.

---

## 🔒 4. Secure Script Execution (Python + Linux)

Demonstrates reading environment variables securely for safe script execution.

---

**Contact:**  
📧 agendrachi92@gmail.com  
🌍 LinkedIn: [Add link here]
