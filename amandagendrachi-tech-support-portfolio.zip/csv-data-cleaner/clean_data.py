import pandas as pd

data = pd.read_csv("client_data.csv")

data.dropna(inplace=True)
data.drop_duplicates(inplace=True)

data["client_name"] = data["client_name"].str.title().str.strip()

data.to_csv("client_data_cleaned.csv", index=False)

print("✅ Data cleaned and saved successfully.")
