import os

api_key = os.getenv("API_KEY")

if not api_key:
    raise ValueError("API key not found! Set API_KEY in environment variables.")
else:
    print("✅ Secure environment variable loaded successfully.")
