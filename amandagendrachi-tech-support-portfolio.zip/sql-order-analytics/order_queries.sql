CREATE TABLE orders (
  id INTEGER PRIMARY KEY,
  customer TEXT,
  product TEXT,
  price REAL
);

INSERT INTO orders (customer, product, price) VALUES
('Alice', 'Shampoo', 12.99),
('Bob', 'Conditioner', 14.50),
('Alice', 'Hair Spray', 8.75);

SELECT customer, SUM(price) AS total_spent
FROM orders
GROUP BY customer
ORDER BY total_spent DESC;
